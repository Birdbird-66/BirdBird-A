#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<netdb.h>

#include<regex.h>

#include<openssl/ssl.h>
#include<openssl/err.h>
#include<sys/mman.h>


//url

typedef struct{
	char alpha_url[4096];  //原始url地址
	char domain[1024];     //域名
	char save_path[1024];   //存储路径
	char save_file[1024];  //资源文件名
	char domain_ip[16];  //服务端公网ip
	int  http_type; //0表示http ,1表示https
	int port; //服务端端口
}url_t;


typedef struct{
	SSL * sslsocket;   //安全套接字
        SSL_CTX * sslctx;  //安全认证上下文
}ssl_t;

typedef struct
{
	url_t *node_queue;
	int front;
	int rear;
	int max;
	int cur;
}container_t;

//参数为url结构体，为传入传出参数，传入原始地址，传出详细信息
int spider_analytical_url(url_t *); 
//网络初始化模块，创建socket并返回
int spider_net_init(void);
//与服务端进行TCP连接 ,参数为服务端网络信息
int spider_connect_webserver(int ,url_t*);
//创建构造http请求头 , 传入地址，传出请求头， node为服务端url信息
int spider_create_request_head(char *,url_t *node);

//下载模块，发送请求，接收响应并处理 , 如果ssl为NULL表示http交互方式，否则https交互方式
int spider_response_download(int ,const char *,url_t *,ssl_t*);

//参数为响应头，查找并返回响应头中的响应状态码(int)
int spider_get_statuscode(const char*);

//安全认证过程  基于连接
ssl_t * spider_openssl_create(int);

//容器创建初始化
container_t *spider_container_create(int);
//容器添加节点
int spider_container_setnode(container_t* , url_t);
//从容器中获取
int spider_container_getnode(container_t* ,url_t*);
// URL去重校验并添加到容器中 , 成功添加返回0 , 重复则失败返回-1
int spider_remove_duplication(container_t* ,container_t* ,const char *);
//链接解析及内容解析
int spider_analytical_html(url_t*, container_t* ,container_t* );
//爬虫控制器，抓取过程
int spider_url_controler(const char *);

