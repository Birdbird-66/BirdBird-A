#include<SPIDER.h>

int spider_url_controler(const char * origin_url)
{
	int webfd;
	char req_head[4096];
	bzero(req_head,4096);
	container_t *u_ct = NULL;
	container_t *p_ct = NULL;
	u_ct = spider_container_create(1000);
	p_ct = spider_container_create(200000);

	url_t node,rnode;
	ssl_t *ssl = NULL;


	if(!spider_remove_duplication(u_ct,p_ct,origin_url))
	{
		strcpy(node.alpha_url,origin_url);
		spider_container_setnode(u_ct,node);
	}

	while(u_ct->cur !=0){
		spider_container_getnode(u_ct,&rnode);

		webfd = spider_net_init();

		spider_analytical_url(&rnode);

		spider_connect_webserver(webfd,&rnode);

		spider_create_request_head(req_head,&rnode);

		if(rnode.http_type)
			ssl = spider_openssl_create(webfd);

		if((spider_response_download(webfd,req_head,&rnode,ssl)) == 0){
			spider_container_setnode(p_ct,rnode);
			spider_analytical_html(&rnode,u_ct,p_ct);
		}
		else
			continue;
	}
	return 0;
}
