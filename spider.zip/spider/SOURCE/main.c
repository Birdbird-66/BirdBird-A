#include<SPIDER.h>

int main()
{
	const char *turl1 = "https://seopic.699pic.com/photo/40202/3604.jpg_wh1200.jpg";
        const char *turl = "https://baike.baidu.com/item/%E7%BD%91%E7%BB%9C%E7%88%AC%E8%99%AB/5162711?fr=aladdin";       
        spider_url_controler(turl);

	return 0;
}
