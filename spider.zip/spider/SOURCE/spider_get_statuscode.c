#include<SPIDER.h>

int spider_get_statuscode(const char* res_head)
{
	// HTTP/1.1 200 OK  
	int statuscode = 0;
	char stat[20]; //取出的200是字符串类型的 ->整形
	bzero(stat,20);
    
	int cnum = 2;//正则表达式数量（父子表达式总数量）
	regex_t reg; //正则类型（使用正则语句生成）
        regmatch_t match[cnum];//传出位置数组长度 ，为正则数量
    
	regcomp(&reg ,"HTTP/1.1 \\([^\r\n]\\+\\?\\)\r\n",0); //生成正则类型   \\转义 正则表达式需要一次转义 编译器需要一次转义

	//通过正则类型从数据源中匹配抽取数据，每次返回一条结果
	if((regexec(&reg , res_head ,cnum ,match ,0)) == 0)
		snprintf(stat,match[1].rm_eo - match[1].rm_so + 1,"%s",res_head+match[1].rm_so); //向stat数组里面写固定长度的字符
        sscanf(stat,"%d ",&statuscode); //把200转换成整形 注意%d后有个空格 200 OK 转换200

	return statuscode;
}
