#include<SPIDER.h>


int spider_net_init(void)
{
	int sockfd;
	struct sockaddr_in myaddr;
	bzero(&myaddr,sizeof(myaddr));
	myaddr.sin_family = AF_INET;
	myaddr.sin_port = htons(8000);
	myaddr.sin_addr.s_addr = htonl(INADDR_ANY);

	sockfd = socket(AF_INET,SOCK_STREAM,0);
	bind (sockfd,(struct sockaddr*)&myaddr,sizeof(myaddr));

	printf("[1] Spider Net Initializer Successfully sockfd [%d]...\n",sockfd);

	return sockfd;


}
