#include<SPIDER.h>

container_t *spider_container_create(int csize)
{
	container_t *ct = NULL;
	ct = (container_t*)malloc(sizeof(container_t));
	ct->node_queue = (url_t *)malloc(sizeof(url_t) * csize);
	ct->front = 0;
	ct->rear = 0;
	ct->cur = 0;
	ct->max = csize;
	return ct;
}
