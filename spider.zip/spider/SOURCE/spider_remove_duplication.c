#include<SPIDER.h>

int spider_remove_duplication(container_t* u_ct ,container_t* p_ct ,const char * url)
{
	int flags;
	flags = u_ct->rear;
	while(flags % u_ct->max != u_ct->front){
		if((strncmp(u_ct->node_queue[flags].alpha_url,url,strlen(url))) == 0)
			return -1;
		flags++;
	}
	flags = p_ct->rear;

	while(flags % p_ct->max != p_ct->front){
		if((strncmp(p_ct->node_queue[flags].alpha_url,url,strlen(url))) == 0)
			return -1;
		flags++;
	}

	return 0;
}
