
#include<SPIDER.h>
//构建请求头
int spider_create_request_head(char* head ,url_t* node)
{
	bzero(head,4096);

	//将请求头字段存放到head中
	sprintf(head,"GET %s HTTP/1.1\r\n"
	                "Accept :text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\n" 
	                "User-Agent:Mozilla/5.0 (X11;Linus X86_64) Chrom/47.0\r\n"
	                "HOST:%s\r\n"
	                "CONNECTion:close\r\n\r\n", node->alpha_url , node->domain);

	printf("[4] Create Request Head Successfully:\n%s",head);

	return 0;
}
