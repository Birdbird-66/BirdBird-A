#include<SPIDER.h>

int spider_response_download(int webfd , const char* req_head , url_t* node , ssl_t* ssl)
{
	char buffer[8192];
	char res_head[4096];
	int rsize;
	char *pos = NULL;
	int fd;
	bzero(buffer,sizeof(buffer));
	bzero(res_head,sizeof(res_head));

	if(!ssl)
	{
		send(webfd,req_head,strlen(req_head),0);
		printf("[5] HTTP Request_head Send To Webserver Successfully...\n");

		rsize = recv(webfd,buffer,sizeof(buffer),0);
		if((pos = strstr(buffer,"\r\n\r\n")) == NULL)
		{
			printf("spider_response_download strstr not found..\n");
			return -1;
		}

		snprintf(res_head,pos - buffer + 4,"%s",buffer);
		printf("[6] HTTP Get Response Head Successfully :\n%s",res_head);
		
		fd = open(node->save_file,O_RDWR|O_CREAT,0775);
		write(fd,pos + 4,rsize - (pos - buffer + 4));

		while((rsize = recv(webfd,buffer,sizeof(buffer),0)) > 0){
			write(fd,buffer,rsize);
			bzero(buffer,sizeof(buffer));
		}
		printf("[7] HTTP Download Successfully...\n");
		return 0;
	}
	else
	{
		SSL_write(ssl->sslsocket,req_head,strlen(req_head));
		printf("[5] HTTPS Request_head Send To Webserver Successfully...\n");
		rsize = SSL_read(ssl->sslsocket,buffer,sizeof(buffer));

		if((pos = strstr(buffer,"\r\n\r\n")) == NULL)
		{
			printf("spider_response_download strstr not found..\n");
			return -1;
		}

		snprintf(res_head,pos - buffer + 4,"%s",buffer);
		printf("[6] HTTPS Get Response Head Successfully :\n%s",res_head);
	
		fd = open(node->save_file,O_RDWR|O_CREAT,0775);
		write(fd,pos + 4,rsize - (pos - buffer + 4));

		while((rsize = SSL_read(ssl->sslsocket,buffer,sizeof(buffer))) > 0)
		{
			write(fd,buffer,rsize);
			bzero(buffer,sizeof(buffer));
		}

	    printf("[7] HTTPS Download Successfully...\n");
	    free(ssl);
	    ssl = NULL;
	    return 0;

	}
	close(fd);
	close(webfd);
	return -1;
}
