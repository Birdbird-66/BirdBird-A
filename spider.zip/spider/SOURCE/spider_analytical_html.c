#include<SPIDER.h>

int spider_analytical_html(url_t* node, container_t* u_ct, container_t* p_ct)
{
	//词条名：<h1 >(网络爬虫)</h1> cnum = 2  匹配1次

	//词条描述：<meta name="description" content="(词条描述)"> cnum = 2   meta标签没有尾 匹配1次

	//更多词条链接:<a (可能包含其他字段) href="(/item/词条链接地址)"(包含其他字段 )>链接标题</a>   cnum = 2
	//匹配n次
	//打开网页源码  
	int fd = open(node->save_file,O_RDONLY);
	int fsize = lseek(fd,0,SEEK_END); 

	//将网页源码数据映射到映射内存
	char *pstring = mmap(NULL ,fsize ,PROT_READ ,MAP_PRIVATE ,fd ,0);
	char *jstr = pstring; //多次匹配 涉及偏移
	url_t rnode;

	//正则准备

	const char *h1_pst = "<h1 >\\([^<]\\+\\?\\)</h1>";
	const char *des_pst = "<meta name=\"description\" content=\"\\([^\"]\\+\\?\\)\">";
	const char *a_pst = "<a[^>]\\+\\?href=\"\\(/item/[^\"]\\+\\?\\)\"[^>]\\+\\?>[^<]\\+\\?</a>";

	regex_t h_reg,d_reg,a_reg;
	int cnum =2;

	regmatch_t h_ma[cnum];
	regmatch_t d_ma[cnum];
	regmatch_t a_ma[cnum];  //匹配成功 传出位置数组

	char h1[1024]; //标题 h1
	char url[4096]; // 超链接 a标签
	char desc[4096];  //描述 meta

	bzero(h1,1024);
	bzero(url,4096);
	bzero(desc,4096);

	regcomp(&h_reg,h1_pst,0);
	regcomp(&d_reg,des_pst,0);
	regcomp(&a_reg,a_pst,0);

	if((regexec(&h_reg,pstring,cnum,h_ma,0)) == 0)
		snprintf(h1,h_ma[1].rm_eo - h_ma[1].rm_so +1,"%s",pstring +h_ma[1].rm_so);
	if((regexec(&d_reg,pstring,cnum,d_ma,0)) == 0){
		snprintf(desc,d_ma[1].rm_eo - d_ma[1].rm_so +1,"%s",pstring +d_ma[1].rm_so);
	}
	//控制 new url解析
	if(u_ct->cur < 100){     //链接要匹配n次
		while((regexec(&a_reg,pstring,cnum,a_ma,0)) == 0){
			snprintf(url,a_ma[1].rm_eo -a_ma[1].rm_so + 24,"https://baike.baidu.com%s",pstring+a_ma[1].rm_so);
			//将新的url去重添加到容器中
			if(u_ct->cur != u_ct->max){
				if(!spider_remove_duplication(u_ct,p_ct,url)){
					strcpy(rnode.alpha_url,url);
					spider_container_setnode(u_ct,rnode);
				}
				bzero(url,sizeof(url));
				pstring+=a_ma[0].rm_eo; //向后偏移寻找下一个a标签

				//解析完毕 是否删除文件
				unlink(node->save_file);
			}else
				break;
		}
	}

	//调用save将解析的内容存储
	
	printf("Analytical_Html TITLE[%s]\n",h1);
	printf("Analytical_Html DESCRIPTION[%s]\n",desc);
	printf("Analytical_Html This URL [%s]\n",node->alpha_url);
	regfree(&h_reg);
	regfree(&d_reg);
	regfree(&a_reg);

	munmap(jstr,fsize); //释放映射  jstr首地址
	close(fd); 
  

	return 0;
}
