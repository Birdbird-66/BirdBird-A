#include<SPIDER.h>

int spider_container_getnode(container_t *ct,url_t* node)
{
	if(ct->cur == 0)
		return -1;
	*node = ct->node_queue[ct->rear];
	ct->rear = (ct->rear +1)%ct->max;
	--(ct->cur);
	return 0;
}
