#include<SPIDER.h>

int spider_connect_webserver(int webfd ,url_t *node)
{
	struct sockaddr_in webaddr;
	bzero(&webaddr,sizeof(webaddr));
	webaddr.sin_family = AF_INET;
	webaddr.sin_port = htons(node->port);
	inet_pton(AF_INET,node->domain_ip,&webaddr.sin_addr.s_addr);
	      
	if((connect(webfd,(struct sockaddr *)&webaddr,sizeof(webaddr))) ==0)
	    printf("[3] Connect Webserver Successfully ...\n");

    return 0;
}

