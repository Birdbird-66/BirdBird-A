#include<SPIDER.h>
ssl_t* spider_openssl_create(int webfd)
{
	ssl_t *ssl = NULL;

	if((ssl = (ssl_t*)malloc(sizeof(ssl_t)))== NULL) //申请空间
	{
		perror("openssl_create malloc ssl error");
		return NULL;
	}
	SSL_load_error_strings();
	SSL_library_init();
	OpenSSL_add_ssl_algorithms();

	ssl->sslctx = SSL_CTX_new(SSLv23_method());  //生成安全认证上下文

	ssl->sslsocket = SSL_new(ssl->sslctx);   //生成安全套接字

	SSL_set_fd(ssl->sslsocket,webfd); //与连接好的webfd进行关联

	SSL_connect(ssl->sslsocket);  //安全认证
        printf("------openssl connect succefffully!------\n");

	return ssl;
}


