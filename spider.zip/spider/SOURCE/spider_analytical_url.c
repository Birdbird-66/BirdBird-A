#include<SPIDER.h>

int spider_analytical_url(url_t *node)
{
	int flags;
	int j = 0;
	int start; //保存http/https  首部长度

	char* http_arry[] ={"http://","https://",NULL}; //http 类型

	int fsize = 0;

	bzero(node->domain , 1024);
	bzero(node->save_path , 1024);
	bzero(node->save_file , 1024);
	bzero(node->domain_ip , 16);
    
   //辨别协议类型
	if(strncmp(node->alpha_url , http_arry[0], strlen(http_arry[0])) == 0)
	{
		node->http_type = 0;
		node->port = 80;
		start = strlen(http_arry[0]);
	}else{
		node->http_type = 1;
		node->port = 443;
		start = strlen(http_arry[1]);
	}

	//alpha中获取域名
	for(flags = start; node -> alpha_url[flags] != '/' && node->alpha_url[flags] != '\0';flags++)
	{
		node->domain[j] = node->alpha_url[flags];
		j++;
	}
	 
	j = 0;

	//http://  tuba.top.com  /   cs/bin/tmp  /2021.jpg

	//alpha中获取文件名  
	
	//先获取整个url的长度  从后向前获取文件名长度
	for(flags = strlen(node->alpha_url);node->alpha_url[flags]!='/';flags--, fsize++);
	
	//获取文件名 整体url长度- 文件名长度 ='/'的位置 再+1就是文件名第一个字符的位置
	for(flags = strlen(node->alpha_url)- fsize + 1;node->alpha_url[flags] != '\0';flags++)
	{
		node->save_file[j] = node->alpha_url[flags];
		j++;
	}
 
	//alpha中获取存储路径
	j = 0;
	for(flags = start +strlen(node->domain);flags<strlen(node->alpha_url)-fsize+1;flags++)
	{
		node->save_path[j] = node->alpha_url[flags];
		j++;
	}
	//gethostbyname 参数传域名返回公网ip 函数依靠网络
	struct hostent* ent = NULL;  //结构体hostent其中一个成员为域名绑定的公网ip地址列表
	ent = gethostbyname(node->domain);   //h_addr_list  这其中的哪一个ip都可以被访问 

	if(ent){
		inet_ntop(AF_INET,ent->h_addr_list[0],node->domain_ip,16);
		printf("[2] Anslytical url Successfully ...\n");
		printf("alpha_url:%s\ndomain:%s\nsave_path:%s\nsave_file:%s\nIP:%s\nPORT:%d\nhttp_type:%d\n",
		node->alpha_url,node->domain,node->save_path,node->save_file,node->domain_ip,node->port,node->http_type);
	}
	
	return 0;
}


